function T=Trasy(l)

T = [1  0  0  0;
     0  1  0  l;
     0  0  1  0;
     0  0  0  1];
     
