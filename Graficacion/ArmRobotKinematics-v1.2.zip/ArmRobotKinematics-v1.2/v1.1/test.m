
for z = 1.6:-0.05:0.15
  #robot3_inv(0,1,z);
  robot2_1_inv(1,z,0);
  pause(0.01);
endfor;

